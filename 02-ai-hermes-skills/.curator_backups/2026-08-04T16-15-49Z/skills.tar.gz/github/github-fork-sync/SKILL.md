---
name: github-fork-sync
description: "Automated fork synchronization using custom GitHub Actions."
---
# GitHub Fork Sync

Use this procedure to automate synchronization of your forks with upstream repositories, avoiding unreliable third-party marketplace actions.

See `references/upstream-sync.md` for the workflow implementation.
