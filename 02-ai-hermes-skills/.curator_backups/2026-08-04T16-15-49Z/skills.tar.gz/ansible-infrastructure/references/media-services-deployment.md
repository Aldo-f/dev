# Media Services Deployment (05-media-*) - Fix Summary

## Problem Identified (2026-08-04)

The `container_services` list in `ansible/roles/containers/defaults/main.yml` included 05-media-plex, 05-media-qbittorrent, and 05-media-nextcloud, but their runtime directories didn't exist and the compose templates had issues:

| Service | Template Issue | Missing Runtime Dir |
|---------|---------------|---------------------|
| plex | `network_mode: host` (incompatible with traefik_net), relative paths `./config`, `~/media/movies` | `/home/aldo/dev/01-core-infra/plex/` |
| qbittorrent | No network config, no restart policy, relative paths `./config`, `./downloads` | `/home/aldo/dev/01-core-infra/qbittorrent/` |
| nextcloud | Used `${MYSQL_ROOT_PASSWORD}` env vars without .env template, hardcoded `/mnt/HDD1/nextcloud` | `/home/aldo/dev/01-core-infra/nextcloud/` |

## Fixes Applied

### 1. Plex Template (`templates/infra/05-media-plex/docker-compose.yml`)
- **Removed** `network_mode: host` (incompatible with Traefik bridge network)
- **Added** `traefik_net` network
- **Replaced** relative paths with absolute HDD paths:
  - `/mnt/HDD1/plex/config:/config`
  - `/mnt/HDD1/media/movies:/movies`
  - `/mnt/HDD1/media/tv:/tv`
- **Added** `restart: unless-stopped`

### 2. Qbittorrent Template (`templates/infra/05-media-qbittorrent/docker-compose.yml`)
- **Added** `traefik_net` network
- **Added** `restart: unless-stopped`
- **Replaced** relative paths with absolute HDD paths:
  - `/mnt/HDD1/qbittorrent/config:/config`
  - `/mnt/HDD1/downloads:/downloads`

### 3. Nextcloud Template (`templates/infra/05-media-nextcloud/docker-compose.yml`)
- **Removed** obsolete `version: '3.9'` field (Docker Compose v2 ignores it)
- **Replaced** hardcoded env vars with placeholders:
  - `${MYSQL_ROOT_PASSWORD}`
  - `${MYSQL_PASSWORD}`
- **Kept** absolute path `/mnt/HDD1/nextcloud:/var/www/html`

### 4. Traefik Routes (`templates/infra/04-network-traefik/routes.yml`)
Added HTTP router entries for:
- `plex.aldof.duckdns.org` → `plex:32400`
- `qbittorrent.aldof.duckdns.org` → `qbittorrent:8080`

Each with:
- HTTPS redirect middleware
- TLS certResolver: myresolver

### 5. Vault Credentials (`vaults/nextcloud-credentials.yml`)
Created placeholder vault file:
```yaml
vault_nextcloud_mysql_root_password: "changeme_root"
vault_nextcloud_mysql_password: "changeme_user"
```

### 6. Containers Role (`ansible/roles/containers/tasks/main.yml`)
Added `include_vars` task to load nextcloud vault credentials before deployment.

## Verification Commands

```bash
# Verify templates are valid YAML
python3 -c "import yaml; [yaml.safe_load(open(f)) for f in ['templates/infra/05-media-plex/docker-compose.yml', 'templates/infra/05-media-qbittorrent/docker-compose.yml', 'templates/infra/05-media-nextcloud/docker-compose.yml']]"

# Verify containers are running
docker ps | grep -E 'plex|qbittorrent'

# Verify Traefik routes are synced
docker exec traefik cat /etc/traefik/routes.yml | grep -A 5 'plex\|qbittorrent'
```

## Important Notes

### Separate Nextcloud Instance
A separate Nextcloud instance exists at `/home/aldo/dev/06-apps-nextcloud/` (managed outside 01-core-infra) with its own docker-compose.yml. The 05-media-nextcloud template deploys a *second* instance. Coordinate to avoid port/volume conflicts.

### User Preference
User prefers routes.yml for Traefik configuration (not Docker labels on containers). All Traefik routing is managed centrally via the routes.yml template.