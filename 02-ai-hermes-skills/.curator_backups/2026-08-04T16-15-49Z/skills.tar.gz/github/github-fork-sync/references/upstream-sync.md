# Fork Upstream Sync Workflow

For repositories that need to stay in sync with an upstream source (e.g., forks of public repositories), avoid unreliable marketplace actions. Use a robust GitHub Action workflow that performs a merge.

Create `.github/workflows/sync-upstream.yml`:

```yaml
name: Sync Upstream
on:
  schedule:
    - cron: '0 0 * * *' # Daily at midnight
  workflow_dispatch:
jobs:
  sync:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - name: Checkout Fork
        uses: actions/checkout@v4
        with:
          token: ${{ secrets.GITHUB_TOKEN }}
          fetch-depth: 0

      - name: Sync Upstream
        run: |
          git remote add upstream https://github.com/<owner>/<repo>.git
          git fetch upstream
          git checkout master
          git merge upstream/master
          git push origin master
```
