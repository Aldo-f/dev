# Hermes WebUI Deployment via Ansible

## Overview
Hermes WebUI is deployed via Ansible playbook in `01-core-infra`. The service runs on port 8787 and is accessible at `web.hermes.dev.aldof.duckdns.org`.

## Template Location
```
templates/infra/02-ai-hermes-webui/docker-compose.yml
```

## Key Configuration

### Docker Compose Template
```yaml
services:
  hermes-webui:
    build:
      context: /home/aldo/dev/02-ai-hermes-webui
      dockerfile: Dockerfile
    container_name: hermes-webui
    restart: unless-stopped
    expose:
      - "8787"
    networks:
      - traefik_net
    volumes:
      - /home/aldo/.hermes:/home/hermeswebui/.hermes
      - /home/aldo/workspace:/workspace
    environment:
      - HERMES_WEBUI_HOST=0.0.0.0
      - HERMES_WEBUI_PORT=8787
      - HERMES_WEBUI_STATE_DIR=/home/hermeswebui/.hermes/webui
      - HERMES_WEBUI_PASSWORD=${HERMES_WEBUI_PASSWORD}
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8787/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 20s

networks:
  traefik_net:
    external: true
```

### Container Service Registration
Add to `ansible/roles/containers/defaults/main.yml`:
```yaml
  - name: 02-ai-hermes-webui
    runtime_dir: "/home/aldo/dev/01-core-infra/02-ai-hermes-webui"
```

### Traefik Route
```yaml
    hermes-http:
      rule: "Host(`web.hermes.dev.aldof.duckdns.org`)"
      entryPoints:
        - web
      middlewares:
        - https-redirect
        - ipAllowList
      service: hermes-webui
    hermes:
      rule: "Host(`web.hermes.dev.aldof.duckdns.org`)"
      entryPoints:
        - websecure
      service: hermes-webui
      tls:
        certResolver: myresolver
      middlewares:
        - ipAllowList
```

## Service URL
- Internal: `http://hermes-webui:8787`
- External: `https://web.hermes.dev.aldof.duckdns.org`

## Common Issues

### Port Already in Use
If `./ctl.sh start` fails with "live server already responding on 127.0.0.1:8787", the service is running outside Docker (direct Python). Kill the process and restart via Docker.

### Health Check Failing
The health check uses `curl` inside the container. If the service starts but health check fails, wait for startup (20s start_period) before testing.

## Verification
```bash
# Check container status
docker ps | grep hermes-webui

# Test health endpoint
curl -s http://localhost:8787/health

# Test external access (from internal network)
curl -I https://web.hermes.dev.aldof.duckdns.org
```