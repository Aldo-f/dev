---
name: hermes-webui-deployment
category: devops
description: Deploy Hermes WebUI via Ansible idempotently
---

# Hermes WebUI Deployment via Ansible (01-core-infra)

**Trigger**: When you need to ensure Hermes WebUI is properly deployed and configured as part of the 01-core-infra infrastructure setup.

**Key Patterns**:
- Always deploy to `/home/aldo/dev/02-ai-hermes-webui` (matches current manual setup)
- Use `become: no` for git operations and file checks (they work fine as user aldo)
- Use `become: true` only for systemd service file deployment (requires root)
- Use `lookup('env', 'HOME')` to get the real user's home directory when running with become
- Ensure service file includes `Environment=HERMES_WEBUI_HOST=0.0.0.0` for LAN access
- Make sure the service uses the existing start.sh script from the repo

**Idempotent Tasks to Add to site.yml**:

```yaml
# HERMES WEBUI DEPLOYMENT TASKS
- name: Ensure hermes-webui directory exists
  file:
    path: "{{ lookup('env', 'HOME') }}/dev/02-ai-hermes-webui"
    state: directory
    owner: aldo
    group: aldo
  become: false

- name: Clone or update hermes-webui repo
  git:
    repo: https://github.com/nesquena/hermes-webui.git
    dest: "{{ lookup('env', 'HOME') }}/dev/02-ai-hermes-webui"
    version: main
    force: yes
  become: false

- name: Ensure start.sh is executable
  file:
    path: "{{ lookup('env', 'HOME') }}/dev/02-ai-hermes-webui/start.sh"
    mode: '0755'
  become: false

- name: Deploy hermes-webui systemd service
  copy:
    dest: /etc/systemd/system/app-hermes-webui.service
    content: |
      [Unit]
      Description=Hermes WebUI Service
      After=network.target

      [Service]
      Environment=HERMES_WEBUI_HOST=0.0.0.0
      ExecStart={{ lookup('env', 'HOME') }}/dev/02-ai-hermes-webui/start.sh
      WorkingDirectory={{ lookup('env', 'HOME') }}/dev/02-ai-hermes-webui
      Restart=always
      User={{ ansible_user_id }}

      [Install]
      WantedBy=multi-user.target
    owner: root
    group: root
    mode: '0644'
  notify:
    - Reload systemd
    - Enable and start hermes-webui
```

**Handlers to Add**:
```yaml
  handlers:
    - name: Reload systemd
      command: systemctl daemon-reload

    - name: Enable and start hermes-webui
      systemd:
        name: app-hermes-webui.service
        enabled: yes
        state: started
```

**Common Pitfalls**:
- Using `ansible_env.HOME` with `become: true` resolves to `/root` instead of `/home/aldo` - use `lookup('env', 'HOME')` instead
- Forgetting to set `become: false` for git/file operations (they work fine as the regular user)
- Not setting proper ownership on the deployed directory (should be aldo:aldo)
- Using hardcoded paths instead of leveraging the HOME environment variable
- Forgetting to notify handlers to actually start/enable the service after deploying the unit file

**Verification Steps**:
1. After running the playbook, check: `systemctl status app-hermes-webui.service`
2. Verify it's active and listening on port 8787: `ss -tlnp | grep 8787`
3. Confirm it's accessible from another machine on your LAN: `http://<your-pi-ip>:8787`
4. Check the service file: `cat /etc/systemd/system/app-hermes-webui.service`